import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import { ExplorePage } from "@/components/explore-page"

export default async function Explore() {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  return <ExplorePage userId={user.id} />
}
