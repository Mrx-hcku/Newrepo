import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import { Feed } from "@/components/feed"

export default async function FeedPage() {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  return <Feed userId={user.id} />
}
