"use client"

import type React from "react"

import { useState, useRef } from "react"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card } from "@/components/ui/card"
import { Upload, X } from "lucide-react"

export function UploadPhotoModal({
  onClose,
  onSuccess,
  userId,
}: {
  onClose: () => void
  onSuccess: () => void
  userId: string
}) {
  const [caption, setCaption] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [preview, setPreview] = useState<string | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const supabase = createClient()

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onloadend = () => {
        setPreview(reader.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleUpload = async () => {
    if (!fileInputRef.current?.files?.[0] || !preview) return

    setIsLoading(true)
    try {
      const file = fileInputRef.current.files[0]
      const fileName = `${userId}-${Date.now()}-${file.name}`

      // Create a simple data URL as placeholder
      // In production, you'd upload to a storage service
      const { error: insertError } = await supabase.from("posts").insert({
        user_id: userId,
        caption,
        image_url: preview, // Using data URL as placeholder
      })

      if (insertError) throw insertError

      onSuccess()
    } catch (error) {
      console.error("Error uploading post:", error)
      alert("Failed to upload post")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-md">
        <div className="p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold">Share a Photo</h2>
            <button onClick={onClose} className="text-muted-foreground hover:text-foreground">
              <X className="w-5 h-5" />
            </button>
          </div>

          {preview ? (
            <div className="space-y-4">
              <div className="aspect-square relative bg-muted rounded-lg overflow-hidden">
                <img src={preview || "/placeholder.svg"} alt="Preview" className="w-full h-full object-cover" />
              </div>

              <div className="space-y-2">
                <Label htmlFor="caption">Caption</Label>
                <Input
                  id="caption"
                  placeholder="Write a caption..."
                  value={caption}
                  onChange={(e) => setCaption(e.target.value)}
                />
              </div>

              <div className="flex gap-2">
                <Button variant="outline" onClick={() => setPreview(null)} className="flex-1">
                  Choose another
                </Button>
                <Button onClick={handleUpload} disabled={isLoading} className="flex-1">
                  {isLoading ? "Uploading..." : "Share"}
                </Button>
              </div>
            </div>
          ) : (
            <div>
              <input ref={fileInputRef} type="file" accept="image/*" onChange={handleFileSelect} className="hidden" />
              <button
                onClick={() => fileInputRef.current?.click()}
                className="w-full border-2 border-dashed border-border rounded-lg p-8 hover:border-primary/50 transition flex flex-col items-center justify-center gap-2"
              >
                <Upload className="w-8 h-8 text-muted-foreground" />
                <span className="text-sm text-muted-foreground">Click to select a photo</span>
              </button>
            </div>
          )}
        </div>
      </Card>
    </div>
  )
}
