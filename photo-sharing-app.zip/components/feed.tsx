"use client"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { PostCard } from "./post-card"
import { UploadPhotoModal } from "./upload-photo-modal"
import { Button } from "@/components/ui/button"

interface Post {
  id: string
  user_id: string
  caption: string
  image_url: string
  created_at: string
  profiles: {
    username: string
    avatar_url: string
  }
  likes: { id: string }[]
  comments: { id: string }[]
}

export function Feed({ userId }: { userId: string }) {
  const [posts, setPosts] = useState<Post[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [showUploadModal, setShowUploadModal] = useState(false)
  const supabase = createClient()

  const loadPosts = async () => {
    try {
      const { data, error } = await supabase
        .from("posts")
        .select(`
          id,
          user_id,
          caption,
          image_url,
          created_at,
          profiles:user_id(username, avatar_url),
          likes(id),
          comments(id)
        `)
        .order("created_at", { ascending: false })
        .limit(20)

      if (error) throw error
      setPosts(data as Post[])
    } catch (error) {
      console.error("Error loading posts:", error)
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    loadPosts()

    // Subscribe to new posts
    const channel = supabase
      .channel("posts")
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "posts" }, (payload) => {
        loadPosts()
      })
      .subscribe()

    return () => {
      channel.unsubscribe()
    }
  }, [supabase])

  return (
    <div className="flex flex-col gap-6 max-w-2xl mx-auto">
      <div className="flex justify-center">
        <Button onClick={() => setShowUploadModal(true)} size="lg">
          Share a Photo
        </Button>
      </div>

      {showUploadModal && (
        <UploadPhotoModal
          onClose={() => setShowUploadModal(false)}
          onSuccess={() => {
            setShowUploadModal(false)
            loadPosts()
          }}
          userId={userId}
        />
      )}

      {isLoading ? (
        <div className="text-center py-8">Loading posts...</div>
      ) : posts.length === 0 ? (
        <div className="text-center py-8 text-muted-foreground">
          No posts yet. Start following people to see their photos!
        </div>
      ) : (
        posts.map((post) => <PostCard key={post.id} post={post} currentUserId={userId} onPostUpdate={loadPosts} />)
      )}
    </div>
  )
}
