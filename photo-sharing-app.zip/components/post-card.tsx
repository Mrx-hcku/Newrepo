"use client"

import { useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Heart, MessageCircle, Trash2, ChevronUp } from "lucide-react"
import Image from "next/image"
import Link from "next/link"
import { CommentsSection } from "./comments-section"

interface Post {
  id: string
  user_id: string
  caption: string
  image_url: string
  created_at: string
  profiles: {
    username: string
    avatar_url: string
  }
  likes: { id: string; user_id: string }[]
  comments: { id: string }[]
}

export function PostCard({
  post,
  currentUserId,
  onPostUpdate,
}: {
  post: Post
  currentUserId: string
  onPostUpdate: () => void
}) {
  const [isLiked, setIsLiked] = useState(post.likes.some((like: any) => like.user_id === currentUserId))
  const [likeCount, setLikeCount] = useState(post.likes.length)
  const [showComments, setShowComments] = useState(false)
  const supabase = createClient()

  const handleLike = async () => {
    if (isLiked) {
      const { error } = await supabase.from("likes").delete().eq("post_id", post.id).eq("user_id", currentUserId)

      if (!error) {
        setIsLiked(false)
        setLikeCount(likeCount - 1)
      }
    } else {
      const { error } = await supabase.from("likes").insert({
        post_id: post.id,
        user_id: currentUserId,
      })

      if (!error) {
        setIsLiked(true)
        setLikeCount(likeCount + 1)
      }
    }
  }

  const handleDelete = async () => {
    if (confirm("Delete this post?")) {
      const { error } = await supabase.from("posts").delete().eq("id", post.id)

      if (!error) {
        onPostUpdate()
      }
    }
  }

  return (
    <Card>
      <CardContent className="p-0">
        <div className="bg-muted aspect-square relative">
          <Image src={post.image_url || "/placeholder.svg"} alt={post.caption} fill className="object-cover" />
        </div>

        <div className="p-4 space-y-4">
          <div className="flex items-center justify-between">
            <Link href={`/profile/${post.user_id}`} className="flex items-center gap-2 hover:opacity-70">
              {post.profiles?.avatar_url && (
                <Image
                  src={post.profiles.avatar_url || "/placeholder.svg"}
                  alt={post.profiles.username}
                  width={32}
                  height={32}
                  className="rounded-full"
                />
              )}
              <span className="font-semibold">{post.profiles?.username}</span>
            </Link>
            {post.user_id === currentUserId && (
              <Button variant="ghost" size="sm" onClick={handleDelete}>
                <Trash2 className="w-4 h-4" />
              </Button>
            )}
          </div>

          {post.caption && <p className="text-sm">{post.caption}</p>}

          <div className="flex gap-4">
            <Button variant="ghost" size="sm" onClick={handleLike} className={isLiked ? "text-red-500" : ""}>
              <Heart className="w-4 h-4" fill={isLiked ? "currentColor" : "none"} />
              <span className="ml-1">{likeCount}</span>
            </Button>
            <Button variant="ghost" size="sm" onClick={() => setShowComments(!showComments)}>
              {showComments ? <ChevronUp className="w-4 h-4" /> : <MessageCircle className="w-4 h-4" />}
              <span className="ml-1">{post.comments?.length || 0}</span>
            </Button>
          </div>

          <p className="text-xs text-muted-foreground">{new Date(post.created_at).toLocaleDateString()}</p>

          {showComments && <CommentsSection postId={post.id} userId={currentUserId} />}
        </div>
      </CardContent>
    </Card>
  )
}
