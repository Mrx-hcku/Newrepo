"use client"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import Image from "next/image"
import Link from "next/link"
import { EditProfileModal } from "./edit-profile-modal"

interface Profile {
  id: string
  username: string
  display_name: string
  bio: string
  avatar_url: string
}

interface Post {
  id: string
  image_url: string
  caption: string
}

export function ProfileView({
  profileId,
  currentUserId,
}: {
  profileId: string
  currentUserId: string
}) {
  const [profile, setProfile] = useState<Profile | null>(null)
  const [posts, setPosts] = useState<Post[]>([])
  const [isFollowing, setIsFollowing] = useState(false)
  const [showEditModal, setShowEditModal] = useState(false)
  const supabase = createClient()

  useEffect(() => {
    const loadProfile = async () => {
      const { data: profileData, error: profileError } = await supabase
        .from("profiles")
        .select("*")
        .eq("id", profileId)
        .single()

      if (!profileError && profileData) {
        setProfile(profileData)
      }

      const { data: postsData, error: postsError } = await supabase
        .from("posts")
        .select("id, image_url, caption")
        .eq("user_id", profileId)
        .order("created_at", { ascending: false })

      if (!postsError && postsData) {
        setPosts(postsData)
      }

      if (currentUserId !== profileId) {
        const { data: followData } = await supabase
          .from("follows")
          .select("id")
          .eq("follower_id", currentUserId)
          .eq("following_id", profileId)
          .single()

        setIsFollowing(!!followData)
      }
    }

    loadProfile()
  }, [profileId, currentUserId, supabase])

  const handleFollow = async () => {
    if (isFollowing) {
      await supabase.from("follows").delete().eq("follower_id", currentUserId).eq("following_id", profileId)

      setIsFollowing(false)
    } else {
      await supabase.from("follows").insert({
        follower_id: currentUserId,
        following_id: profileId,
      })

      setIsFollowing(true)
    }
  }

  if (!profile) return <div>Loading...</div>

  const isOwnProfile = profileId === currentUserId

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="flex items-center gap-8">
        {profile.avatar_url && (
          <Image
            src={profile.avatar_url || "/placeholder.svg"}
            alt={profile.username}
            width={120}
            height={120}
            className="rounded-full"
          />
        )}

        <div className="flex-1 space-y-4">
          <div>
            <h1 className="text-3xl font-bold">{profile.display_name}</h1>
            <p className="text-muted-foreground">@{profile.username}</p>
          </div>

          {profile.bio && <p className="text-sm">{profile.bio}</p>}

          <div className="flex gap-2">
            {isOwnProfile ? (
              <Button onClick={() => setShowEditModal(true)}>Edit Profile</Button>
            ) : (
              <Button onClick={handleFollow}>{isFollowing ? "Following" : "Follow"}</Button>
            )}
          </div>
        </div>
      </div>

      {showEditModal && isOwnProfile && (
        <EditProfileModal
          profile={profile}
          onClose={() => setShowEditModal(false)}
          onSuccess={(updatedProfile) => {
            setProfile(updatedProfile)
            setShowEditModal(false)
          }}
        />
      )}

      <div>
        <h2 className="text-2xl font-bold mb-4">Posts ({posts.length})</h2>
        <div className="grid grid-cols-3 gap-4">
          {posts.map((post) => (
            <Link key={post.id} href={`/feed`} className="group relative overflow-hidden rounded-lg">
              <div className="aspect-square bg-muted relative">
                <Image
                  src={post.image_url || "/placeholder.svg"}
                  alt={post.caption}
                  fill
                  className="object-cover group-hover:scale-105 transition"
                />
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  )
}
