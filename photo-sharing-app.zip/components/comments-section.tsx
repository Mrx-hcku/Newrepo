"use client"

import { useState, useEffect } from "react"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import Image from "next/image"
import Link from "next/link"

interface Comment {
  id: string
  content: string
  user_id: string
  created_at: string
  profiles: {
    username: string
    avatar_url: string
  }
}

export function CommentsSection({
  postId,
  userId,
}: {
  postId: string
  userId: string
}) {
  const [comments, setComments] = useState<Comment[]>([])
  const [newComment, setNewComment] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const supabase = createClient()

  useEffect(() => {
    const loadComments = async () => {
      const { data, error } = await supabase
        .from("comments")
        .select(`
          id,
          content,
          user_id,
          created_at,
          profiles:user_id(username, avatar_url)
        `)
        .eq("post_id", postId)
        .order("created_at", { ascending: false })

      if (!error && data) {
        setComments(data as Comment[])
      }
    }

    loadComments()

    const channel = supabase
      .channel(`comments:${postId}`)
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "comments", filter: `post_id=eq.${postId}` },
        (payload) => {
          loadComments()
        },
      )
      .subscribe()

    return () => {
      channel.unsubscribe()
    }
  }, [postId, supabase])

  const handleAddComment = async () => {
    if (!newComment.trim()) return

    setIsLoading(true)
    try {
      const { error } = await supabase.from("comments").insert({
        post_id: postId,
        user_id: userId,
        content: newComment,
      })

      if (error) throw error
      setNewComment("")
    } catch (error) {
      console.error("Error adding comment:", error)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex gap-2">
        <Input
          placeholder="Add a comment..."
          value={newComment}
          onChange={(e) => setNewComment(e.target.value)}
          onKeyPress={(e) => e.key === "Enter" && handleAddComment()}
        />
        <Button onClick={handleAddComment} disabled={isLoading || !newComment.trim()}>
          Post
        </Button>
      </div>

      <div className="space-y-3">
        {comments.map((comment) => (
          <div key={comment.id} className="flex gap-2">
            {comment.profiles?.avatar_url && (
              <Link href={`/profile/${comment.user_id}`}>
                <Image
                  src={comment.profiles.avatar_url || "/placeholder.svg"}
                  alt={comment.profiles.username}
                  width={32}
                  height={32}
                  className="rounded-full"
                />
              </Link>
            )}
            <div className="flex-1">
              <Link href={`/profile/${comment.user_id}`} className="font-semibold text-sm hover:opacity-70">
                {comment.profiles?.username}
              </Link>
              <p className="text-sm">{comment.content}</p>
              <p className="text-xs text-muted-foreground">{new Date(comment.created_at).toLocaleDateString()}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
