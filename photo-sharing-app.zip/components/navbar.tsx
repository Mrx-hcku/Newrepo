"use client"

import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { useState, useEffect } from "react"

export function Navbar() {
  const [user, setUser] = useState<{ id: string; email: string | undefined } | null>(null)
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    const getUser = async () => {
      const {
        data: { user },
      } = await supabase.auth.getUser()
      setUser(user)
    }
    getUser()
  }, [supabase])

  const handleLogout = async () => {
    await supabase.auth.signOut()
    router.push("/auth/login")
  }

  return (
    <nav className="border-b border-border bg-card">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <Link href="/feed" className="text-xl font-bold">
          PhotoShare
        </Link>

        <div className="flex items-center gap-4">
          <Link href="/feed">
            <Button variant="ghost">Feed</Button>
          </Link>
          <Link href="/explore">
            <Button variant="ghost">Explore</Button>
          </Link>
          {user && (
            <>
              <Link href={`/profile/${user.id}`}>
                <Button variant="ghost">Profile</Button>
              </Link>
              <Button variant="outline" onClick={handleLogout}>
                Logout
              </Button>
            </>
          )}
        </div>
      </div>
    </nav>
  )
}
