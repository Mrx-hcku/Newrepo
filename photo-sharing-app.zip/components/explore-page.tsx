"use client"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Image from "next/image"
import Link from "next/link"

interface Profile {
  id: string
  username: string
  display_name: string
  avatar_url: string
  bio: string
}

export function ExplorePage({ userId }: { userId: string }) {
  const [suggestedUsers, setSuggestedUsers] = useState<Profile[]>([])
  const [followingIds, setFollowingIds] = useState<string[]>([])
  const supabase = createClient()

  useEffect(() => {
    const loadSuggestedUsers = async () => {
      // Get users you're not following
      const { data: followingData } = await supabase.from("follows").select("following_id").eq("follower_id", userId)

      const followingSet = new Set(followingData?.map((f: any) => f.following_id) || [])
      followingSet.add(userId) // Don't suggest yourself

      const { data: profilesData } = await supabase.from("profiles").select("*").limit(20)

      const filtered = (profilesData || []).filter((p: Profile) => !followingSet.has(p.id))

      setSuggestedUsers(filtered)
      setFollowingIds(Array.from(followingSet))
    }

    loadSuggestedUsers()
  }, [userId, supabase])

  const handleFollow = async (profileId: string) => {
    await supabase.from("follows").insert({
      follower_id: userId,
      following_id: profileId,
    })

    setSuggestedUsers(suggestedUsers.filter((u) => u.id !== profileId))
  }

  return (
    <div className="max-w-2xl mx-auto">
      <h1 className="text-3xl font-bold mb-8">Explore</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {suggestedUsers.map((profile) => (
          <Card key={profile.id}>
            <CardContent className="p-6 space-y-4">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  {profile.avatar_url && (
                    <Image
                      src={profile.avatar_url || "/placeholder.svg"}
                      alt={profile.username}
                      width={48}
                      height={48}
                      className="rounded-full"
                    />
                  )}
                  <div>
                    <p className="font-semibold">{profile.display_name}</p>
                    <p className="text-sm text-muted-foreground">@{profile.username}</p>
                  </div>
                </div>
                <Button size="sm" onClick={() => handleFollow(profile.id)}>
                  Follow
                </Button>
              </div>
              {profile.bio && <p className="text-sm text-muted-foreground">{profile.bio}</p>}
              <Link href={`/profile/${profile.id}`}>
                <Button variant="outline" className="w-full bg-transparent" size="sm">
                  View Profile
                </Button>
              </Link>
            </CardContent>
          </Card>
        ))}
      </div>

      {suggestedUsers.length === 0 && (
        <div className="text-center py-12 text-muted-foreground">
          You&apos;re following everyone or there are no suggested users.
        </div>
      )}
    </div>
  )
}
